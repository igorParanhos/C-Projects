#include<stdio.h>
#include<stdlib.h>

  /**
  Escreva um algoritmo que leia um conjunto de 50 fichas correspondente
  à alunos e armazene-as em vetores, cada uma contendo, a altura e o
  código do sexo de uma pessoa
  (código = 1 se for masculino e 2 se for feminino), e calcule e imprima:
  * A maior e a menor altura da turma;
  * As mulheres com altura acima da média da altura das mulheres;
  * As pessoas com altura abaixo da média da turma.
  */

int main(){


  return 0;
}
